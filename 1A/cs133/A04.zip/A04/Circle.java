import java.awt.*;

/** 
 * Put description here
 */
public class Circle extends Picture 
{
  /** 
   * Put description here
   */
  public Circle(Color color, int diameter) 
  {
  } // end constructor
  
  

  public static void main(String[] args)
  {    
    Picture orangeOne = new Circle(Board.ORANGE, 1);
    Picture yellowOne = new Circle(Board.YELLOW, 4);
    Picture whiteOne = new Circle(Board.WHITE, 7);
    Picture greenOne = new Circle(Board.GREEN, 2);
    
    Board b = new Board(12, 12);
    orangeOne.drawMe(b, 4, 1);
    yellowOne.drawMe(b, 7, 1);
    whiteOne.drawMe(b, 1, 4);
    greenOne.drawMe(b, 9, 7);
  } // end main
  
} // end class

