import java.awt.*;

/** 
 * Put description here
 */
public class Rectangle extends Picture 
{
   // Add instance variables here.

   /** 
    * Put description here
    */
   public Rectangle(Color color, int height, int width) 
   {
     // Your code here.
   }

   /** 
    * Put description here
    */
   public void drawMe(Board board, int row, int col) 
   {
     // Your code here.
   }

   public static void main(String[] args) 
   {
     Picture test = new Rectangle(Board.BLUE, 5, 6);
     Board board = new Board(9, 12);
     test.drawMe(board, 2, 3);
   }
}
