import java.awt.*;

/** 
 * Put description here
 */
public class Square extends Rectangle 
{
  // Instance variables go here
  
  /** 
   * Put description here
   */
  public Square(Color color, int size) 
  {
  } // end constructor
} // end class
