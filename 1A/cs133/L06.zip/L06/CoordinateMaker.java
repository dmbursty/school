public class CoordinateMaker
{
  public static void createCoordinate(Coordinate newCoordinate, int rows, int columns)
  {
    newCoordinate = new Coordinate(rows, columns);
  }
  
  public static void main(String[] args)
  {
    Coordinate coord = null;
    createCoordinate(coord, 3, 7);
    System.out.println("coord has the value (" + coord.getRow() + ", " + coord.getCol() + ")");
  }
}
