
/**This class manages the interactions between the different pieces of 
 * the game: the Board, the Daleks, and the Doctor. It determines when
 * the game is over and whether the Doctor won or lost.
 * @author CS133 Staff
 */
public class CatchGame
{
  private Board room;  
  private Dalek adam, tim, paul; 
  private Doctor student; // replace this with your name 
  // You may need additional instance variables to solve the problem.
  
  
  
  /**The constructor initializes the variables for the game.
   */
  public CatchGame()
  {
    
    
  }


  /**The playGame method controls the game: deals with when the user
   * selects a square, when the Daleks move, when the game is 
   * won/lost.
   */
  public void playGame()
  {
    

 }
 
  
}
