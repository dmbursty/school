/** MainGame calls the play method of EightMenOnARaft
  * @author CS133 staff
  */
public class MainGame
{
   public static void main (String[] args)
   {
      EightMenOnARaft game = new EightMenOnARaft();
      game.play();
   }
}
