public class MagicSquare
{
    public static boolean isMagic( int[][] a )
    {
        // Check that the 2D array is not null.
        // Your code here.
        
        // Step 1: Is it a square?
        // Your code here.
        
        // Step 2: Are all the values positive?
        // Your code here.
        
        // Step 3: Compute the expected sum.
        // Your code here.
        
        // Step 4: Check the rows.
        // Your code here.
        
        // Step 5: Check the columns.
        // Your code here.
        
        // Step 6: Check the diagonals
        // Your code here.
        
        // Step 7: Check that all values are unique.
        // Your code here.
        
        // For use initially as a stub.
        return true;
    }
    
    public static void main( String[] args )
    {
        int[][] a;
        
        // Null array
        System.out.println( MagicSquare.isMagic(null) );
        
        // Not a square
        a = new int[2][3];
        a[0][0] =  1; a[0][1] =  2; a[0][2] = -3;
        a[0][0] = -1; a[0][1] = -2; a[0][2] =  3;
        System.out.println( MagicSquare.isMagic(a) );
        
        // Not all positive
        a = new int[3][3];
        a[0][0] = -8; a[0][1] = -1; a[0][2] = -6;
        a[1][0] = -3; a[1][1] = -5; a[1][2] = -7;
        a[2][0] = -4; a[2][1] = -9; a[2][2] = -2;
        System.out.println( MagicSquare.isMagic(a) );
        
        // Rows don't add up.
        a = new int[3][3];
        a[0][0] =  1; a[0][1] = 5; a[0][2] = 3;
        a[1][0] = 11; a[1][1] = 9; a[1][2] = 7;
        a[2][0] =  6; a[2][1] = 4; a[2][2] = 8;
        System.out.println( MagicSquare.isMagic(a) );
        
        // Columns don't add up.
        a = new int[3][3];
        a[0][0] = 1; a[0][1] = 11; a[0][2] = 6;
        a[1][0] = 5; a[1][1] =  9; a[1][2] = 4;
        a[2][0] = 3; a[2][1] =  7; a[2][2] = 8;
        System.out.println( MagicSquare.isMagic(a) );
        
        // Diagonals don't add up.
        a = new int[3][3];
        a[0][0] = 3; a[0][1] = 5; a[0][2] = 7;
        a[1][0] = 8; a[1][1] = 1; a[1][2] = 6;
        a[2][0] = 4; a[2][1] = 9; a[2][2] = 2;
        System.out.println( MagicSquare.isMagic(a) );
        
        // Values aren't unique.
        a = new int[3][3];
        a[0][0] = 2; a[0][1] = 2; a[0][2] = 2;
        a[1][0] = 2; a[1][1] = 2; a[1][2] = 2;
        a[2][0] = 2; a[2][1] = 2; a[2][2] = 2;
        System.out.println( MagicSquare.isMagic(a) );
        
        // Valid magic square
        a = new int[3][3];
        a[0][0] = 8; a[0][1] = 1; a[0][2] = 6;
        a[1][0] = 3; a[1][1] = 5; a[1][2] = 7;
        a[2][0] = 4; a[2][1] = 9; a[2][2] = 2;
        System.out.println( MagicSquare.isMagic(a) );
        
        // Valid magic square
        a = new int[5][5];
        a[0][0] = 17; a[0][1] = 24; a[0][2] =  1; a[0][3] =  8; a[0][4] = 15;
        a[1][0] = 23; a[1][1] =  5; a[1][2] =  7; a[1][3] = 14; a[1][4] = 16;
        a[2][0] =  4; a[2][1] =  6; a[2][2] = 13; a[2][3] = 20; a[2][4] = 22;
        a[3][0] = 10; a[3][1] = 12; a[3][2] = 19; a[3][3] = 21; a[3][4] =  3;
        a[4][0] = 11; a[4][1] = 18; a[4][2] = 25; a[4][3] =  2; a[4][4] =  9;
        System.out.println( MagicSquare.isMagic(a) );
    }
}
