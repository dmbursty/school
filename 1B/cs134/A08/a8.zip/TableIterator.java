import java.util.Iterator;

public class TableIterator implements Iterator {
 
  public TableIterator(KeyedItem[] items, int numItems)
  { 
  }

  //post: returns true if the iteration has more elements
  public boolean hasNext()
  {
  }

  //pre:  this.hasNext() == true
  //post: returns the next element in the iteration 
  public Object next()
  {
  }
 
  public void remove()
  {  
    // You are not required to implement this method.
  }
  
}
