import java.awt.Color;

/** 
 * Put description here
 */
public class Peg extends Square 
{
  /** 
   * Put description here
   */
  public Peg(Color color) 
  {
  } // end constructor
} // end class
