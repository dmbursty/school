/**
 * This class manages the interactions between the different pieces of 
 * the game: the Board, the Daleks, and the Doctor. It determines when
 * the game is over and whether the Doctor won or lost.
 * 
 * @author CS133 Staff
 */
public class CatchGame
{
  // Fix up your version from Assignment 2.  You will
  // have to alter it since you will no longer have the
  // getClick() method.  Instead, your game must interact
  // with the board using the BoardListener interface
  // provided in Assignment 5.
}
