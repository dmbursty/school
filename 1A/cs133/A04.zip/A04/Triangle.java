import java.awt.Color;

public class Triangle extends Picture 
{
   public Triangle(Color color, int height, int width) 
   {
   }

   public static void main (String [] args) 
   {
     Board b = new Board(12, 12);
     Picture test1 = new Triangle(Board.ORANGE, 4, 7);
     test1.drawMe(b, 3, 2);
   }

}

