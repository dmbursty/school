import java.awt.*;
import javax.swing.*;

public class Board
{
  // Some colour presets
  public static final Color YELLOW = Color.YELLOW;
  public static final Color BLUE = Color.BLUE;
  public static final Color CYAN = Color.CYAN;
  public static final Color GREEN = Color.GREEN;
  public static final Color PINK = Color.PINK;
  public static final Color BLACK = Color.BLACK;
  public static final Color WHITE = Color.WHITE;
  public static final Color RED = Color.RED;
  public static final Color ORANGE = Color.ORANGE;

  // Instance variables
  JFrame frame;
  
  // Other instance variables
  
  public Board(int rows, int columns)
  {
  }
  
  public void displayMessage(String theMessage)
  {
  }
  
  public void putPeg(Color theColour, int row, int col)
  {
  }
  
  public void removePeg(int row, int col)
  {
  }
  
  public int getColumns()
  {
  }
  
  public int getRows()
  {
  }
  
  public void addBoardListener(BoardListener listener)
  {
    // You need only support a single listener.
  }
  
  public void removeBoardListener()
  {
    // A method you may find useful.
  }
}
