
public interface Simple extends java.rmi.Remote {
    public ServiceReply simpleService(int t1, int s1) throws java.rmi.RemoteException;
}
