import javax.swing.*;
import java.awt.*;

public class BoardPanel
  extends JPanel
{
  // Instance variables
  
  // Some constants for drawing the board.
  // You may need more, and may need to alter
  // these values for some of the extensions.
  public static final int X_DIM = 30;
  public static final int Y_DIM = 30;
  public static final int X_OFFSET = 30;
  public static final int Y_OFFSET = 50;

  // Grid colours
  public static final Color GRID_COLOR_A = new Color(84,137,139);
  public static final Color GRID_COLOR_B = new Color(103,156,158);
  
  public BoardPanel(int rows, int columns)
  {
  }
  
  public void paintComponent(Graphics canvas)
  {
  }
  
  public void putPeg(Color theColour, int row, int column)
  {
  }
  
  public void removePeg(int row, int column)
  {
  }
  
  public void displayMessage(String theMessage)
  {
  }
}