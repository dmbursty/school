import java.util.*;
/**This class manages the interactions between the different pieces of 
 * the game: the Board, the Daleks, and the Doctor. It determines when
 * the game is over and whether the Doctor won or lost.
 * @author CS133 Staff
 */
public class CatchGame
{
  private Board room;  
  private Dalek adam, tim, paul; 
  private Doctor daniel;
  private Coordinate lastClick;
  // You may need additional instance variables to solve the problem.
  
  
  
  /**The constructor initializes the variables for the game.
   */
  public CatchGame()
  {
    room = new Board(12,12);
    adam = new Dalek((int)(Math.random()*11),(int)(Math.random()*11));
    tim = new Dalek((int)(Math.random()*11),(int)(Math.random()*11));
    paul = new Dalek((int)(Math.random()*11),(int)(Math.random()*11));
    daniel = new Doctor((int)(Math.random()*11),(int)(Math.random()*11));
  }


  /**The playGame method controls the game: deals with when the user
   * selects a square, when the Daleks move, when the game is 
   * won/lost.
   */
  public void playGame()
  {
    
    for (;;) {

      room.putPeg(room.GREEN,daniel.getRow(),daniel.getCol());
      room.putPeg(adam.hasCrashed()?room.RED:room.BLACK,adam.getRow(),adam.getCol());
      room.putPeg(tim.hasCrashed()?room.RED:room.BLACK,tim.getRow(),tim.getCol());
      room.putPeg(paul.hasCrashed()?room.RED:room.BLACK,paul.getRow(),paul.getCol());
      
      if ((daniel.getRow() == adam.getRow() && daniel.getCol() == adam.getCol()) || (daniel.getRow() == tim.getRow() && daniel.getCol() == tim.getCol()) || (daniel.getRow() == paul.getRow() && daniel.getCol() == paul.getCol())) {
        room.putPeg(room.YELLOW,daniel.getRow(),daniel.getCol());
        room.displayMessage("You've been captured!");
        break;
      }
      
      if (adam.hasCrashed() && tim.hasCrashed() && paul.hasCrashed()) {
        room.displayMessage("Congratulations! You've survived!");
        break;
      }
      
      lastClick = room.getClick();
      
      room.removePeg(daniel.getRow(),daniel.getCol());
      room.removePeg(adam.getRow(),adam.getCol());
      room.removePeg(tim.getRow(),tim.getCol());
      room.removePeg(paul.getRow(),paul.getCol());
      
      daniel.move(lastClick.getRow(),lastClick.getCol());
      adam.advanceTowards(daniel);
      tim.advanceTowards(daniel);
      paul.advanceTowards(daniel);
      
      if (adam.getRow() == tim.getRow() && adam.getCol() == tim.getCol()) {
        adam.crash();
        tim.crash();
      }
      if (adam.getRow() == paul.getRow() && adam.getCol() == paul.getCol()) {
        adam.crash();
        paul.crash();
      }
      if (paul.getRow() == tim.getRow() && paul.getCol() == tim.getCol()) {
        paul.crash();
        tim.crash();
      }

    }
    
  }
  
}
