
public class TestMyDate
{
  public static void main(String[] args)
  {
    // Write your code here to test that you have properly implemented the MyDate class.

  
  }
}