//Name:
//User Name:
//User ID: 

public class UsingListArray
{
	public static int replace(ListArray list, String s, String t)	// pre: list, s, t are not null; list contains only String values	// post: replaces all occurrences of s in list with t, and returns 	//the number of replacements made.
	{
		
	}
}