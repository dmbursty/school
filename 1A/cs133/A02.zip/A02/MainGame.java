
/**This class creates a game and starts the game play.
 * @author CS133 Staff
 */
public class MainGame
{
  public static void main(String args[])
  {
    CatchGame game = new CatchGame();
    game.playGame();
  }

}
