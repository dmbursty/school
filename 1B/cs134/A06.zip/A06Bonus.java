public class A06Bonus
{
    public static SubListInterface reverse(SubListInterface sub)
    // pre: sub is not null
    // post: returns a sublist containing the elements of sub in reverse order.
    {
        return null;
    }
}
