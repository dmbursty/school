public class A5Q1 {

	public static boolean checkForNestingAndBalanceIn( String str ) {
	    // Pre: 	str is not null.
	    // Post: 	returns true if the brackets (), [] and {} appearing in str are properly
	    //		balanced and nested.
	    // 		Ignores all other characters in str, which therefore do not affect whether
    	//		str is balanced and nested.
	}


}
