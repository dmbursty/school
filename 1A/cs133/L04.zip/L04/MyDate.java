public class MyDate
{
    private int day;
    private int month;
    private int year;

    // Your code goes here.

}
