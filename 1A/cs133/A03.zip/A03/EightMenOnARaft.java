
public class EightMenOnARaft
{

}
