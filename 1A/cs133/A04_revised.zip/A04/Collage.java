/** 
 * Put description here
 */
public class Collage extends Picture 
{
  /** 
   * Put description here
   */
  public Collage() 
  {
  } // end constructor
  
  /** 
   * Add a picture to the collage. 
   * @param picture the picture to add. pre: picture != null
   * @row, column the top-left corner for this picture. 
   *   pre: row, column >= 0 
   */
  public void add(Picture picture, int row, int column) 
  {
  } // end add
  
  public static void main(String[] args) 
  {
    Collage test = new Collage();
    Picture a = new Square(Board.GREEN, 2);
    Picture b = new Square(Board.YELLOW, 3);
    Picture c = new Peg(Board.RED);
    test.add(a, 0, 0);
    test.add(b, 4, 2);
    test.add(c, 2, 4);
    
    Board board = new Board(10, 10);
    test.drawMe(board, 2, 2);
  } // end main
} // end class

