public class A06Q3
{    
    // Question 3(a)
    public static int gcd(int a, int b)
    // pre: a,b >= 0, a + b > 0
    // post: returns greatest common divisor of a and b.
    {
        return 0;
    }
 
    // Question 3(b)
    public static String makePalindrome(String s)
    // pre: s is not null
    // post: creates and returns the String s concatenated with
    // the reverse of s
    {
        return null;
    }
  
    // Question 3(c)
    public static void makeAllPalindromes(SubListInterface s)
    // pre: s!= null, Entries in s are of type String and are not null
    // post: modifies s so that each entry in s is replaced with a
    // palindrome created from the entry
    {
    }

    // Question 3(d)
    public static void replaceItems(SubListInterface s, Object target, Object changeTo)
    // pre: s != null, target != null, changeTo != null
    // post: modifies s so that all entries equivalent (using .equals)
    // to target are replaced with the value changeTo
    {
    }
  
    //Question 3(e)
    public static int[] extremes(SubListInterface s)
    // pre: s!=null, !s.isEmpty(),
    //      all values in s are non-null and of type Integer
    // post: returns an array result of length 2, where
    // result[0] is the minimum int value in s, and
    // result[1] is the maximum int value in s.
    {
        int[] ret = new int[2];
        ret[0] = -1;
        ret[1] = -1;
        return ret;
    }
}
