import java.util.*;

public class SwedishChef
{
  public static void main(String[] args)
  {
 
   //insert code here  
  }
 
  //insert code here
}
