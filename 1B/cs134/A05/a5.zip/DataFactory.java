public class DataFactory
{
   public static QueueInterface makeQueue()
   {  // If you want to use the array-based implementation, change this line below
	return new QueueLinked();
   }

   public static StackInterface makeStack()
   {  // If you want to use the array-based implementation, change the line below
	return new StackLinked();
   }

   public static ListInterface makeList()
   {  // If you want to use the array-based implementation, change the line below
	return new ListLinked();
   }
}
