public class TestHappy
{
  public static void main(String[] args)
  {
    HappyFrame happy = new HappyFrame();
  }
}