import java.awt.*;
import javax.swing.*;

public class HappyPanel extends JPanel
{
  public void paintComponent(Graphics canvas)
  {
    // Circle for the face.
    canvas.drawOval(100, 50, 200, 200);
    
    // Two filled ovals for eyes.
    canvas.fillOval(155, 100, 10, 20);
    canvas.fillOval(230, 100, 10, 20);
    
    // Arc for mouth.
    canvas.drawArc(150, 160, 100, 50, 180, 180);
  }
}
