/**
 * This class models the Doctor in the game. A Doctor has
 * a position and can move to a new position.
 * 
 * @author CS133 Staff
 */
public class Doctor
{
  // Fix up your version from Assignment 2.
}