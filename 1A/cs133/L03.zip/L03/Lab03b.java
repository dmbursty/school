// Description goes here
public class Lab03b 
{
  public static void main(String[] args)
  {
    /* Write all of your code in here */

  }
}
