/**
 * This class models a Delek in the game. A Delek has
 * a position and can advance towards the Doctor.
 * 
 * @author CS133 Staff
 */
public class Dalek
{
  // Fix up your version from Assignment 2.
}