// Description goes here
public class Lab04a 
{
  public static void main(String[] args)
  {
    /* Write all of your code in here */

  }
}
