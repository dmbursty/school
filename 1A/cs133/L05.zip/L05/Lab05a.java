
public class Lab05a
{
   public static void main(String[] args)
   {
      // Your code goes here.

   }
}
